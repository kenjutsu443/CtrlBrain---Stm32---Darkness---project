Src/Audio.o: ../Src/Audio.c ../Inc/Audio.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Device/ST/STM32L4xx/Include/stm32l476xx.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/core_cm4.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_version.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_compiler.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_gcc.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/mpu_armv7.h \
 D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h \
 ../Inc/Systick_timer.h
../Inc/Audio.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Device/ST/STM32L4xx/Include/stm32l476xx.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/core_cm4.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_version.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_compiler.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/cmsis_gcc.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Include/mpu_armv7.h:
D:/SFSU/Engr478/aaLAB/Final_Project/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h:
../Inc/Systick_timer.h:
